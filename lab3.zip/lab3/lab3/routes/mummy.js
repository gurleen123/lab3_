﻿'use strict';
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res) {
    res.render('mummy', { title: 'Mummy', comment: 'My mom is the best coo in the world. I lOve you MOM.' });
});

module.exports = router;