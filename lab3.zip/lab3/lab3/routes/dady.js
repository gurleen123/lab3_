﻿'use strict';
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res) {
    res.render('dady', { title: 'Dady', comment: 'My FATHER is my my best friend and he loves me a lot' });
});

module.exports = router;